package com.johnson.membersDirectory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MembersDirectoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MembersDirectoryApplication.class, args);
	}

}

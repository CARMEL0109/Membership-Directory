package com.johnson.membersDirectory;

import org.springframework.data.repository.CrudRepository;

public interface MembershipRepo extends CrudRepository<Membership, Long> {

}
